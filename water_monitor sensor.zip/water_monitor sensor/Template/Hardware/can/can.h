#ifndef __CAN_H
#define __CAN_H

#include "stm32f10x_it.h"

#define CAN_RX GPIO_Pin_11
#define CAN_TX GPIO_Pin_12

void Can_Init(void);
u8   Can_Send(u32 Id, u8 length, u8 *data);		/* 1=�ɹ���0=ʧ�� */
u8 Can_Receive_FIFOflag(void);
void Can_Receive(u32 *Id, u8 *length, u8 *data);

#endif
