#ifndef __PH_H
#define __PH_H

#include "stm32f10x.h"

typedef struct{
	u8 Channel;
	u8 SampleTimes;
	float K;
	float B;
}PH_Parameter;

void PH_Init(PH_Parameter* stdph, u8 ch, u8 times, float k, float b);
float PH_GetValue(PH_Parameter* stdph);
float PH_GetVoltage(PH_Parameter* stdph);

#endif
