#ifndef __OLED_H
#define __OLED_H

#include "stm32f10x.h"

#define OLED_WIDTH 	128
#define OLED_HEIGHT 64

#define OLED_CMD  0	//д����
#define OLED_DATA 1	//д����

void OLED_Init(void);

void OLED_On(void);
void OLED_Display_On(void);
void OLED_Display_Off(void);
void OLED_Clear(void);
void OLED_DrawPoint(u8 x,u8 y,u8 t);
void fill_picture(unsigned char fill_Data);
void OLED_ShowChar(u8 x,u8 y,u8 chr,u8 Char_Size);
void OLED_ShowNum(u8 x,u8 y,u32 num,u8 len,u8 size2);
void OLED_ShowString(u8 x,u8 y, u8 *chr,u8 Char_Size);	 
void OLED_Set_Pos(unsigned char x, unsigned char y);
void OLED_ShowCHinese(u8 x,u8 y,u8 no);
void OLED_DrawBMP(unsigned char x0, unsigned char y0,unsigned char x1, unsigned char y1,unsigned char BMP[]);

void OLED_Write_Cmd(unsigned char cmd);
void OLED_Write_Data(unsigned char data);
void OLED_WR_Byte(u8 dat, u8 cmd);

#endif
