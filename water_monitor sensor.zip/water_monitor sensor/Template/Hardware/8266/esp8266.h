#ifndef __ESP8266_H
#define __ESP8266_H

#include "stm32f10x.h"

/* ===== WiFi 配置（手机热点/路由器） ===== */
#define WIFI_SSID     "11"
#define WIFI_PASSWORD "83078193"

/* ===== 巴法云平台账号 ===== */
#define BEMFA_UID      "6d0386c65aba1fb9b85c2b2a5f0f04c1"
#define BEMFA_TOPIC    "waterquality001"

#define PING_PERIOD_MS  15000u   /* 心跳间隔，巴法云要求 <60s */
#define RETRY_PERIOD_MS 8000u    /* 断线后多久重新开始 */

/* 调试开关：1 = 把 AT 交互过程从蓝牙(USART3/HC06)打印出来
 *           0 = 不打印（正式运行时关掉，省时间）
 * 注意：9600 波特率下每行打印要阻塞约 1ms/字符，正式跑请置 0 */
#define ESP_DEBUG  0

typedef struct {
	GPIO_TypeDef* GPIOx;
	u32 TX_Pin;
	u32 RX_Pin;
	u32 ESP_RCC;
} ESP_GPIO;

extern ESP_GPIO esp;

void    ESP8266_Init(void);
void    ESP8266_Scan(void);
void    ESP8266_SendData(float temp, float ph, float tds);
uint8_t ESP8266_IsConnected(void);
void    ESP8266_SetCmdCallback(void (*cb)(const char *, uint16_t));
const char* ESP8266_StateName(void);

#endif
