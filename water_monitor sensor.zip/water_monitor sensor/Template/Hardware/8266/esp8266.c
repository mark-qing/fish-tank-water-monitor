/**
 * esp8266.c  —— ESP8266(AT 固件) + 巴法云 TCP 设备云
 *
 * 相对旧版修正的 4 个致命点：
 *  1) 必须 AT+CIPMODE=1 之后再 AT+CIPSEND 进入“透传”，否则 STM32 直接发出的
 *     cmd=1&uid=... / cmd=2&... 会被模块当成 AT 命令、只回 ERROR，永远到不了巴法云。
 *  2) 接收改成“按行组包”：旧版一次 Scan 就把缓冲区取空，半包被丢弃，
 *     "OK"/"WIFI GOT IP" 几乎永远匹配不上，状态机卡在 AT 这一步。
 *  3) '>' 提示符后面没有换行，必须按字节识别（按行永远等不到）。
 *  4) 断线时用 "+++" 退出透传，再重新走 AT 流程。
 *
 * 接线：PA9 -> ESP8266 RX, PA10 <- ESP8266 TX, 共地，ESP 独立 3.3V 供电(>=500mA)
 */

#include "esp8266.h"
#include "tim3.h"
#include <string.h>
/* 注意：这里故意不引 stdio.h —— 不用 printf/snprintf，
 * 既省 flash（64KB 的 C8T6 很紧），也几乎不占栈（栈只有 1KB 且不能改） */

#if ESP_DEBUG
#include "hc06.h"
#endif

/* ================= 接线配置 ================= */
ESP_GPIO esp = {
    .GPIOx   = GPIOA,
    .RX_Pin  = GPIO_Pin_10,
    .TX_Pin  = GPIO_Pin_9,
    .ESP_RCC = RCC_APB2Periph_GPIOA,
};

/* ================= 接收环形缓冲区（只在中断里写） ================= */
#define RB_SIZE  512
#define RB_MASK  (RB_SIZE - 1)

static volatile uint8_t  rb[RB_SIZE];
static volatile uint16_t rb_head = 0, rb_tail = 0;

static void (*s_cmd_cb)(const char *, uint16_t) = 0;

/* 行缓冲：中断只负责收字节，主循环把字节拼成“一行”再解析 */
#define LINE_MAX 128
static char     line_buf[LINE_MAX];
static uint16_t line_len = 0;

/* ================= 状态机 ================= */
typedef enum {
    ST_WAIT_RETRY = 0,
    ST_EXIT_PASS,       /* 透传中，已发 +++，等 1s 以上再发 AT */
    ST_AT,
    ST_ECHO,
    ST_MODE,
    ST_CWSTATE,         /* 查 AT+CWSTATE?，已经连上热点就不用再 CWJAP */
    ST_JAP,
    ST_MUX,
    ST_CIPMODE,
    ST_START,
    ST_CIPSEND,         /* 等 '>'，随后进入透传 */
    ST_READY
} State;

static State    state       = ST_WAIT_RETRY;
static uint8_t  connected   = 0;
static uint8_t  passthrough = 0;
static uint8_t  cw_got_ip   = 0;    /* AT+CWSTATE? 查询结果：已经拿到 IP */
static uint8_t  skip_ok     = 0;    /* 下一条若是多余的收尾 OK 就丢掉 */
static uint8_t  retry_cnt   = 0;    /* 连续失败次数 */
static uint32_t step_start  = 0;
static uint32_t last_ping   = 0;
static uint32_t last_rx_ms  = 0;    /* 最后一次收到模块/服务器数据的时间 */
static uint32_t retry_at    = 0;

static char        cmd_text[96];       /* 当前这一步的命令（不带 \r\n） */
static const char *expect   = "OK";
static uint32_t    timeout  = 2000;

/* ================= 小工具 ================= */

static void ESP_LOG(const char *s)
{
#if ESP_DEBUG
    if (strlen(s) < 78) {
        Serial_Printf("[ESP] %s\r\n", s);
    }
#else
    (void)s;
#endif
}

void USART1_IRQHandler(void)
{
    if (USART_GetITStatus(USART1, USART_IT_RXNE) != RESET) {
        uint8_t  c    = (uint8_t)USART_ReceiveData(USART1);
        uint16_t next = (uint16_t)((rb_head + 1) & RB_MASK);

        if (next == rb_tail) {              /* 满了丢最旧的一个字节 */
            rb_tail = (uint16_t)((rb_tail + 1) & RB_MASK);
        }
        rb[rb_head] = c;
        rb_head     = next;
    }
    if (USART_GetFlagStatus(USART1, USART_FLAG_ORE) != RESET) {  /* 清溢出 */
        (void)USART_ReceiveData(USART1);
    }
}

static uint16_t RB_Pop(uint8_t *dst, uint16_t max)
{
    uint16_t n = 0;
    while (rb_tail != rb_head && n < max) {
        dst[n++] = rb[rb_tail];
        rb_tail  = (uint16_t)((rb_tail + 1) & RB_MASK);
    }
    return n;
}

static void Send(const char *s)
{
    uint32_t guard = GetTick_ms();

    while (*s) {
        while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET) {
            if (GetTick_ms() - guard > 100) return;   /* 不卡死 */
        }
        USART_SendData(USART1, (uint16_t)(uint8_t)(*s++));
        guard = GetTick_ms();
    }
}

/* ================= 无 printf 的字符串/数字拼接 ================= */

static char *AppendStr(char *p, const char *s)
{
    while (*s != '\0') *p++ = *s++;
    *p = '\0';
    return p;
}

/* 无符号整数，不足 min_digits 位时左边补 '0' */
static char *AppendUInt(char *p, uint32_t v, uint8_t min_digits)
{
    char    tmp[10];
    uint8_t n = 0;

    do {
        tmp[n++] = (char)('0' + (v % 10u));
        v /= 10u;
    } while (v != 0 && n < sizeof(tmp));

    while (n < min_digits && n < sizeof(tmp)) tmp[n++] = '0';
    while (n > 0) *p++ = tmp[--n];
    *p = '\0';
    return p;
}

/* 定点数：val = 真实值 * 10^dec，dec=1 -> x.x，dec=2 -> x.xx
 * 例：AppendFixed(p, -53, 1) -> "-5.3"；AppendFixed(p, 723, 2) -> "7.23" */
static char *AppendFixed(char *p, int32_t val, uint8_t dec)
{
    uint32_t div = 1u;
    uint32_t u;
    uint8_t  i;

    for (i = 0; i < dec; i++) div *= 10u;

    if (val < 0) {
        *p++ = '-';
        u = (uint32_t)(-val);
    } else {
        u = (uint32_t)val;
    }

    p = AppendUInt(p, u / div, 1);

    if (dec != 0) {
        *p++ = '.';
        *p   = '\0';
        p = AppendUInt(p, u % div, dec);
    }
    return p;
}

/* ================= 状态机推进 ================= */

static void SendCmdText(void)
{
    char  b[104];
    char *p;

    if (cmd_text[0] == '\0') return;
    if (strlen(cmd_text) > (sizeof(b) - 3)) return;

    p = b;
    p = AppendStr(p, cmd_text);
    p = AppendStr(p, "\r\n");
    Send(b);
}

static void Go(State s, const char *cmd, const char *exp, uint32_t tmo)
{
    state      = s;
    expect     = (exp != 0) ? exp : "";
    timeout    = tmo;
    step_start = GetTick_ms();

    if (cmd != 0) {
        strncpy(cmd_text, cmd, sizeof(cmd_text) - 1);
        cmd_text[sizeof(cmd_text) - 1] = '\0';
        ESP_LOG(cmd_text);
        SendCmdText();
    } else {
        cmd_text[0] = '\0';
    }
}

/* need_exit: 1 表示当前还在透传里，需要先发 +++ 退回 AT 模式 */
static void ToRetry(uint8_t need_exit)
{
    connected = 0;

    /* 连续失败 3 次：可能 WiFi 真的掉了（模块不会主动告诉你），强制重新关联 */
    retry_cnt++;
    if (retry_cnt >= 3) {
        retry_cnt = 0;
    }

    if (passthrough && need_exit) {
        Send("+++");
        passthrough = 0;
        state       = ST_EXIT_PASS;
        step_start  = GetTick_ms();
        ESP_LOG("+++ (exit transparent)");
        return;
    }

    passthrough = 0;
    state       = ST_WAIT_RETRY;
    retry_at    = GetTick_ms() + RETRY_PERIOD_MS;
}

/* 进入透传：发巴法云订阅报文 */
static void EnterPass(void)
{
    char  sub[96];
    char *p;

    passthrough = 1;
    connected   = 1;
    last_ping   = GetTick_ms();
    last_rx_ms  = GetTick_ms();
    retry_cnt   = 0;
    state       = ST_READY;
    cmd_text[0] = '\0';

    p = sub;
    p = AppendStr(p, "cmd=1&uid=");
    p = AppendStr(p, BEMFA_UID);
    p = AppendStr(p, "&topic=");
    p = AppendStr(p, BEMFA_TOPIC);
    p = AppendStr(p, "\r\n");
    Send(sub);

    ESP_LOG("<< SUBSCRIBE sent, transparent mode ON");
}

/* 当前行是不是这一步等待的应答 */
static uint8_t MatchExpect(const char *line)
{
    if (state == ST_JAP) {
        /* 老固件 AT+CWJAP 成功只回 OK；新固件回 WIFI GOT IP。两个都认 */
        return (strstr(line, "GOT IP") != 0) || (strcmp(line, "OK") == 0);
    }
    if (state == ST_START) {
        /* 新固件回 CONNECT(+OK)，老固件只回 OK */
        return (strstr(line, "CONNECT") != 0) || (strcmp(line, "OK") == 0);
    }
    if (expect[0] == '\0') return 0;
    return (strstr(line, expect) != 0);
}

static void HandleLine(char *line)
{
    uint32_t now = GetTick_ms();

    if (line[0] == '\0') return;

    last_rx_ms = now;          /* 有线就有心跳，用于判断链路是否还活着 */
    ESP_LOG(line);

    /* CWJAP 的应答是 "WIFI CONNECTED / WIFI GOT IP / OK" 三行，
     * 我们已经用 GOT IP 推进了状态，最后那个 OK 要丢掉，
     * 否则会被下一状态当成 CIPMUX 的应答，整条流水线错位。 */
    if (skip_ok) {
        skip_ok = 0;
        if (strcmp(line, "OK") == 0) return;
    }

    /* 模块忙：这条命令被丢了，重发一次 */
    if (strstr(line, "busy") != 0) {
        SendCmdText();
        step_start = now;
        return;
    }

    /* WiFi 掉了：只有"已经连上之后"掉才算数。
     * AT+CWJAP 关联过程中模块会先打印一条 WIFI DISCONNECT（切换 AP 的正常现象），
     * 把它当成掉线就会变成"每 8 秒重连一次、热点连上又退"的死循环。 */
    if (strstr(line, "WIFI DISCONNECT") != 0) {
        if (state == ST_READY) {
            ESP_LOG("<< WIFI lost, restart");
            ToRetry(0);
        }
        return;
    }

    /* TCP 掉线 / 连接失败（这些情况下模块已自动回到 AT 模式） */
    if (strstr(line, "link is not valid") != 0 ||
        strstr(line, "CONNECT FAIL") != 0 ||
        strcmp(line, "CLOSED") == 0) {
        ESP_LOG("<< tcp closed, restart");
        ToRetry(0);
        return;
    }

    /* 查询是否已经连上热点：+CWSTATE:2 表示已连接且拿到 IP */
    if (state == ST_CWSTATE) {
        if (strstr(line, "+CWSTATE:2") != 0) {
            cw_got_ip = 1;
            return;
        }
        if (strstr(line, "+CWSTATE:") != 0) {
            cw_got_ip = 0;
            return;
        }
        if (strstr(line, "ERROR") != 0) {      /* 老固件不支持这条查询 */
            cw_got_ip = 0;
            Go(ST_JAP, "AT+CWJAP=\"" WIFI_SSID "\",\"" WIFI_PASSWORD "\"",
               "GOT IP", 25000);
            return;
        }
        if (strcmp(line, "OK") == 0) {         /* 查询命令的结束标志，在这里再决策 */
            if (cw_got_ip) {
                Go(ST_MUX, "AT+CIPMUX=0", "OK", 3000);
            } else {
                Go(ST_JAP, "AT+CWJAP=\"" WIFI_SSID "\",\"" WIFI_PASSWORD "\"",
                   "GOT IP", 25000);
            }
            return;
        }
        return;
    }

    /* 已经透传：剩下的都是巴法云下发的数据 */
    if (state == ST_READY) {
        if (strstr(line, "cmd=1&res=1") != 0) {
            ESP_LOG("<< BEMFA SUBSCRIBE OK");
        }
        if (s_cmd_cb != 0) s_cmd_cb(line, (uint16_t)strlen(line));
        return;
    }

    if (!MatchExpect(line)) return;         /* 不是这一步要的应答 */

    switch (state) {
    case ST_AT:
        Go(ST_ECHO, "ATE0", "OK", 2000);
        break;

    case ST_ECHO:
        Go(ST_MODE, "AT+CWMODE=1", "OK", 2000);
        break;

    case ST_MODE:
        /* 先问一句"现在连上热点了吗"：已经连上就直接跳过 CWJAP，
         * 否则反复 CWJAP 会把模块踢下线，手机上看到"热点连上又退" */
        cw_got_ip = 0;
        Go(ST_CWSTATE, "AT+CWSTATE?", "", 3000);
        break;

    case ST_CWSTATE:
        break;

    case ST_JAP:
        skip_ok = 1;        /* 后面还会跟一个 OK，丢掉它 */
        Go(ST_MUX, "AT+CIPMUX=0", "OK", 3000);
        break;

    case ST_MUX:
        Go(ST_CIPMODE, "AT+CIPMODE=1", "OK", 3000);   /* ★ 必须先开透传 */
        break;

    case ST_CIPMODE:
        Go(ST_START, "AT+CIPSTART=\"TCP\",\"bemfa.com\",8344", "CONNECT", 12000);
        break;

    case ST_START:
        Go(ST_CIPSEND, "AT+CIPSEND", ">", 5000);      /* 应答 '>' 无换行 */
        break;

    default:
        break;
    }
}

/* 从环形缓冲区取字节 -> 拼行 / 识别 '>' */
static void PumpRx(void)
{
    uint8_t  chunk[32];
    uint16_t n, i;
    uint8_t  c;

    while ((n = RB_Pop(chunk, sizeof(chunk))) > 0) {
        for (i = 0; i < n; i++) {
            c = chunk[i];

            /* CIPSEND 的 '>' 后面没有换行，只能按字节抓 */
            if (state == ST_CIPSEND && c == '>') {
                EnterPass();
                continue;
            }

            if (c == '\r') continue;

            if (c == '\n') {
                line_buf[line_len] = '\0';
                line_len = 0;
                HandleLine(line_buf);
                continue;
            }

            if (line_len < (LINE_MAX - 1)) {
                line_buf[line_len++] = (char)c;
            } else {
                line_len = 0;       /* 开机乱码太长，丢掉重来 */
            }
        }
    }
}

/* ================= USART1 初始化 ================= */
static void USART1_Init(void)
{
    GPIO_InitTypeDef  GPIO_InitStructure;
    USART_InitTypeDef USART_InitStructure;
    NVIC_InitTypeDef  NVIC_InitStructure;

    RCC_APB2PeriphClockCmd(esp.ESP_RCC | RCC_APB2Periph_USART1, ENABLE);

    GPIO_InitStructure.GPIO_Pin   = esp.TX_Pin;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(esp.GPIOx, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin  = esp.RX_Pin;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(esp.GPIOx, &GPIO_InitStructure);

    USART_InitStructure.USART_BaudRate            = 115200;
    USART_InitStructure.USART_WordLength          = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits            = USART_StopBits_1;
    USART_InitStructure.USART_Parity              = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode                = USART_Mode_Rx | USART_Mode_Tx;
    USART_Init(USART1, &USART_InitStructure);

    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);

    NVIC_InitStructure.NVIC_IRQChannel                   = USART1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority        = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd                = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    USART_Cmd(USART1, ENABLE);
}

/* ================= 对外接口 ================= */
void ESP8266_Init(void)
{
    USART1_Init();

    rb_head = rb_tail = 0;
    line_len    = 0;
    line_buf[0] = '\0';
    cmd_text[0] = '\0';

    connected   = 0;
    passthrough = 0;
    retry_cnt   = 0;

    /* ★ STM32 单独复位时，ESP8266 很可能还停在"透传"里 ——
     *   这时发 AT 会被当成 TCP 数据发给巴法云，永远回不了 OK，
     *   表现就是"点一下复位，8266 就再也连不上了"。
     *   所以上电先发 +++ 把模块踹回 AT 模式，等 1.5s 再发 AT。 */
    Send("+++");
    state      = ST_EXIT_PASS;
    step_start = GetTick_ms();
}

void ESP8266_Scan(void)
{
    uint32_t now;

    PumpRx();                            /* 收数据、拼行、推进状态机 */

    now = GetTick_ms();

    if (state == ST_EXIT_PASS) {
        if (now - step_start >= 1500) {  /* 透传退出需要 1s 以上静默 */
            Go(ST_AT, "AT", "OK", 2000);
        }
        return;
    }

    if (state == ST_WAIT_RETRY) {
        if ((int32_t)(now - retry_at) >= 0) {
            Go(ST_AT, "AT", "OK", 2000);
        }
        return;
    }

    if (state == ST_READY) {
        /* 看门狗：模块被复位/掉电后不会主动告诉我们，
         * 但服务器对 cmd=2 和 ping 都会回 cmd=x&res=1，
         * 30s 一条都没收到就说明链路已经死了 */
        if (now - last_rx_ms > 30000) {
            ESP_LOG("<< no reply 30s, restart");
            ToRetry(1);
            return;
        }
        if (passthrough && (now - last_ping >= PING_PERIOD_MS)) {
            Send("cmd=0&msg=ping\r\n");   /* 巴法云心跳（60s 内必须发） */
            last_ping = now;
        }
        return;
    }

    if (now - step_start > timeout) {    /* 这一步超时，整套重来 */
        ESP_LOG("<< timeout, restart");
        ToRetry(passthrough);
    }
}

uint8_t ESP8266_IsConnected(void)
{
    return connected;
}

/* 浮点 -> 定点整数，四舍五入（7.23f*100 会变成 722.9999，不加 0.5 会显示 7.22） */
static int32_t RoundTo(float v, float scale)
{
    float s = v * scale;
    return (int32_t)((s < 0.0f) ? (s - 0.5f) : (s + 0.5f));
}

void ESP8266_SendData(float temp, float ph, float tds)
{
    char  msg[128];
    char *p;

    if (!connected || !passthrough) return;

    p = msg;
    p = AppendStr(p, "cmd=2&uid=");
    p = AppendStr(p, BEMFA_UID);
    p = AppendStr(p, "&topic=");
    p = AppendStr(p, BEMFA_TOPIC);
    p = AppendStr(p, "&msg=#");
    p = AppendFixed(p, RoundTo(temp, 10.0f),  1);   /* 等价于 %.1f，无效时是 -127.0 */
    p = AppendStr(p, "#");
    p = AppendFixed(p, RoundTo(ph,  100.0f), 2);    /* 等价于 %.2f */
    p = AppendStr(p, "#");
    p = AppendFixed(p, RoundTo(tds, 1.0f),   0);    /* TDS 取整，单位 ppm */
    p = AppendStr(p, "\r\n");

    Send(msg);
}

void ESP8266_SetCmdCallback(void (*cb)(const char *, uint16_t))
{
    s_cmd_cb = cb;
}

const char* ESP8266_StateName(void)
{
    /* 每个名字补齐到 8 个字符，方便直接贴到 OLED 上覆盖旧内容 */
    static const char *names[] = {
        "RETRY   ", "EXIT    ", "AT      ", "ATE0    ",
        "CWMODE  ", "CWSTATE ", "CWJAP   ", "CIPMUX  ",
        "CIPMODE ", "CIPSTART", "CIPSEND ", "READY   "
    };
    if ((int)state < 0 || (int)state > 11) return "?       ";
    return names[(int)state];
}
