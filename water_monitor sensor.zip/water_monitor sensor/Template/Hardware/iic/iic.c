#include "iic.h"
#include "Systick.h"

#define SCL_L() GPIO_ResetBits(iic->IIC_GPIO_PORT, iic->SCL_PIN)
#define SCL_H() GPIO_SetBits(iic->IIC_GPIO_PORT, iic->SCL_PIN)
#define SDA_L() GPIO_ResetBits(iic->IIC_GPIO_PORT, iic->SDA_PIN)
#define SDA_H() GPIO_SetBits(iic->IIC_GPIO_PORT, iic->SDA_PIN)
#define SDA_R() GPIO_ReadInputDataBit(iic->IIC_GPIO_PORT, iic->SDA_PIN)

void IIC_Init(IIC_TypeDef *iic)
{
	GPIO_InitTypeDef gpio;
	
	RCC_APB2PeriphClockCmd(iic->IIC_RCC, ENABLE);
	
	gpio.GPIO_Pin 	= iic->SCL_PIN | iic->SDA_PIN;
//	gpio.GPIO_Mode 	= GPIO_Mode_Out_PP;
	gpio.GPIO_Mode 	= GPIO_Mode_Out_OD;
	gpio.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(iic->IIC_GPIO_PORT, &gpio);
	
	SCL_H();
	SDA_H();
}

//void SDA_Set_Out(IIC_TypeDef *iic)
//{
//	GPIO_InitTypeDef gpio;
//	
//	RCC_APB2PeriphClockCmd(iic->IIC_RCC, ENABLE);
//	
//	gpio.GPIO_Pin 	= iic->SDA_PIN;
//	gpio.GPIO_Mode 	= GPIO_Mode_Out_PP;
//	gpio.GPIO_Speed = GPIO_Speed_50MHz;
//	GPIO_Init(iic->IIC_GPIO_PORT, &gpio);
//}

//void SDA_Set_In(IIC_TypeDef *iic)
//{
//	GPIO_InitTypeDef gpio;
//	
//	RCC_APB2PeriphClockCmd(iic->IIC_RCC, ENABLE);
//	
//	gpio.GPIO_Pin 	= iic->SDA_PIN;
//	gpio.GPIO_Mode 	= GPIO_Mode_IN_FLOATING;
//	gpio.GPIO_Speed = GPIO_Speed_50MHz;
//	GPIO_Init(iic->IIC_GPIO_PORT, &gpio);
//}

void IIC_Start(IIC_TypeDef *iic)
{
//	SDA_Set_Out(iic);
	
	SDA_H();
	SCL_H();
	delay_us(5);
	SDA_L();
	delay_us(5);
	SCL_L();
}

void IIC_Stop(IIC_TypeDef *iic)
{
//	SDA_Set_Out(iic);
	
	SCL_L();
	SDA_L();
	delay_us(5);
	SCL_H();
	delay_us(5);
	SDA_H();
	delay_us(5);
	
}

//������ӻ���������ack��������ֻ��oled��ʾ������Ҫ��������ack��û�õ��˺���
void IIC_Send_Ack(IIC_TypeDef *iic, u8 ack)
{
//	SDA_Set_Out(iic);
	
	SCL_L();
	delay_us(5);
	if(ack==0)
		SDA_L();
	else
		SDA_H();
	
	SCL_H();
	delay_us(5);
	SCL_L();
	SDA_H();
}

u8 IIC_Wait_Ack(IIC_TypeDef *iic)
{
//	SDA_Set_In(iic);
	
	u8 ack_status=1;
	SCL_L();
	delay_us(5);
	SCL_H();
	delay_us(5);
	
	if(SDA_R()==0)
		ack_status=0;
	else
		ack_status=1;
	
	SCL_L();
	delay_us(5);
	return ack_status;

}

void IIC_SendByte(IIC_TypeDef *iic, u8 data)
{
//	SDA_Set_Out(iic);
	
	u8 i;
	for(i=0; i<8; i++){
		SCL_L();
		if(data&0x80)
			SDA_H();
		else 
			SDA_L();
		
		data<<=1;
		delay_us(5);
		SCL_H();
		delay_us(5);
	}
	SCL_L();
	
//	return IIC_Wait_Ack(iic); 
}
