#ifndef __IIC_H
#define __IIC_H

#include "stm32f10x.h"

typedef struct IIC_Structure{
	GPIO_TypeDef* IIC_GPIO_PORT;
	u32 SCL_PIN;
	u32 SDA_PIN;
	u32 IIC_RCC;
}IIC_TypeDef;

void IIC_Init(IIC_TypeDef *iic);
void IIC_Start(IIC_TypeDef *iic);
void IIC_Stop(IIC_TypeDef *iic);
void IIC_Send_Ack(IIC_TypeDef *iic, u8 ack);
u8 IIC_Wait_Ack(IIC_TypeDef *iic);
void IIC_SendByte(IIC_TypeDef *iic, u8 data);

#endif
