#include "tim3.h"

volatile u32 ms_ticks = 0;   // �� ȫ����Ψһ�Ķ��崦

void TIM3_Timebase_Init(void)
{
    TIM_TimeBaseInitTypeDef t;
    NVIC_InitTypeDef n;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);

    t.TIM_Prescaler   = 72 - 1;      // 72MHz / 72 = 1MHz
    t.TIM_Period      = 1000 - 1;    // 1MHz / 1000 = 1ms
    t.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM3, &t);

    TIM_ClearFlag(TIM3, TIM_FLAG_Update);   // ��һ�ι����־����ֹһ���жϾͽ�
    TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE);
    TIM_Cmd(TIM3, ENABLE);

    n.NVIC_IRQChannel = TIM3_IRQn;
    n.NVIC_IRQChannelPreemptionPriority = 1;
    n.NVIC_IRQChannelSubPriority = 0;
    n.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&n);
}

u32 GetTick_ms(void)
{
    return ms_ticks;
}

void TIM3_IRQHandler(void)
{
    if (TIM_GetITStatus(TIM3, TIM_IT_Update) != RESET) {
        TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
        ms_ticks++;
    }
}
