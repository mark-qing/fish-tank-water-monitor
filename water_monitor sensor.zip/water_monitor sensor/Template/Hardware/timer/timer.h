#ifndef __TIMER_H
#define __TIMER_H

#include "stm32f10x_it.h"

typedef struct{
	u32 period;
	u32 last;	// �ϴδ���ʱ��
	u8 enable;	// ʹ�ܱ�־
}SoftTimer;	

void TIM2_Init(void);
void Timer_Scan(void);
u32 GetTick_us(void);
u8 SoftTimer_Check(SoftTimer *t, u32 now);
u8 SoftTimer_Checkus(SoftTimer *t);

#endif
