#ifndef _TIM3_H
#define _TIM3_H

#include "stm32f10x.h"

extern volatile u32 ms_ticks;

void TIM3_Timebase_Init(void);
u32 GetTick_ms(void);

#endif
