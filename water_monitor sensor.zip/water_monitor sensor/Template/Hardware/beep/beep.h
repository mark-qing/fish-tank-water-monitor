#ifndef __BEEP_H
#define __BEEP_H

#include "stm32f10x.h"

typedef struct{
	GPIO_TypeDef* GPIOx;
	u32 BEEP_Pin;
	u32 BEEP_RCC;
}BEEP_GPIO;

typedef struct{
	u16 temp_min;
	u16 temp_max;
	float tds_max;
	float ph_min;
	float ph_max;
}BEEP_Parameter;

extern BEEP_GPIO beep;
extern BEEP_Parameter beep_para;
extern u8 beep_en;				/* 1=��������������0=���� */

extern int16_t temperature;
extern u8      ds_ok;
extern float   tds_value;
extern float   ph_val;

void BEEP_On(void);
void BEEP_Off(void);
void BEEP_Init(void);
void Alarm(void);
void BEEP_Toggle(void);

#endif
