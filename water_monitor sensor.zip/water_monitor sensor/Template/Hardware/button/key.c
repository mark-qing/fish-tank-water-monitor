#include "key.h"
#include "timer.h"
#include "tim3.h"

KEY_GPIO key={
	.GPIOx=GPIOB,
	.KEY_RCC=RCC_APB2Periph_GPIOB,
	.K1_Pin=GPIO_Pin_3,
	.K2_Pin=GPIO_Pin_4,
};

SoftTimer t_key={
	.period=20,
	.last=0,
	.enable=1,
};

void KEY_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);
	
	RCC_APB2PeriphClockCmd(key.KEY_RCC, ENABLE);
	GPIO_InitTypeDef GPIO_InitStructure;
	
	GPIO_InitStructure.GPIO_Pin=key.K1_Pin | key.K2_Pin;
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IPU;
	GPIO_Init(key.GPIOx, &GPIO_InitStructure);
	
}

u8 KEY_Scan(void)
{
    if(!SoftTimer_Check(&t_key, GetTick_ms())) return 0;

    static u8 k1_cnt=0, k2_cnt=0, k1_state=1, k2_state=1;
    u8 ret = 0;
    u8 k1 = GPIO_ReadInputDataBit(key.GPIOx, key.K1_Pin);
    u8 k2 = GPIO_ReadInputDataBit(key.GPIOx, key.K2_Pin);

    /* K1������2�β���Ϊ0ȷ�ϰ��£�40ms������ */
    if(k1 == 0){ if(k1_cnt < 3) k1_cnt++; } else k1_cnt = 0;
    if(k1_cnt >= 2 && k1_state == 1){ ret |= 1; k1_state = 0; }  // ���� |=������ =
    if(k1 == 1) k1_state = 1;

    /* K2 ͬ�� */
    if(k2 == 0){ if(k2_cnt < 3) k2_cnt++; } else k2_cnt = 0;
    if(k2_cnt >= 2 && k2_state == 1){ ret |= 2; k2_state = 0; }
    if(k2 == 1) k2_state = 1;

    return ret;   // bit0=K1��bit1=K2
}
