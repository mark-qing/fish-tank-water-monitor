#ifndef __KEY_H
#define __KEY_H

#include "stm32f10x.h"

typedef struct{
	GPIO_TypeDef* GPIOx;
	u32 K1_Pin;
	u32 K2_Pin;
	u32 KEY_RCC;
}KEY_GPIO;

void KEY_Init(void);
u8 KEY_Scan(void);

#endif
