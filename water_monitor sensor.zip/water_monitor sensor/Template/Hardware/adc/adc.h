#ifndef __ADC_H
#define __ADC_H

#include "stm32f10x.h"

typedef struct{
	ADC_TypeDef* ADCx;
	GPIO_TypeDef* GPIOx;
	u32 ADC_RCC;
	u32 GPIO_RCC;
}ADC_Parameter;

typedef struct{
	u32 GPIO_Pin;
	u32 ADC_Channel;
}ADC_GPIO;

extern ADC_Parameter adc;
extern ADC_GPIO tds_gpio;
extern ADC_GPIO	ph_gpio;

void Adc_Init(void);
u16 Get_Adc(u8 ch);
u16 Get_Adc_Average(u8 ch, u8 times);
float Get_Adc_Voltage(u8 ch, u8 times);

#endif
