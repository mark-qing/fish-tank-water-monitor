#include "tds.h"
#include "adc.h"

void TDS_Init(TDS_Parameter *ptds, u8 ch, u8 times, float temp, float k)
{
	ptds->Channel	  =ch;
	ptds->SampleTimes =times;
	ptds->Temperature =temp;
	ptds->K_Value	  =k;
}

float TDS_GetPPM(TDS_Parameter *ptds)
{
	float voltage, comp, v, tds;
	
	voltage=Get_Adc_Voltage(ptds->Channel, ptds->SampleTimes);
	
	comp=1.0f+0.02f*(ptds->Temperature-25.0f);
	v=voltage/comp;
	
	tds=(133.42f*v*v*v
		-255.86f*v*v
		+857.39f*v)*0.5f;
	
	return tds*ptds->K_Value;
}
