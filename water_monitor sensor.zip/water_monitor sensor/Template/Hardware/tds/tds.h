#ifndef __TDS_H
#define __TDS_H

#include "stm32f10x.h"

typedef struct{
	u8 Channel;
	u8 SampleTimes;
	float Temperature;
	float K_Value;
}TDS_Parameter;

void TDS_Init(TDS_Parameter *ptds, u8 ch, u8 times, float temp, float k);
float TDS_GetPPM(TDS_Parameter *ptds);

#endif
