#ifndef __HC06_H
#define __HC06_H

#include "stm32f10x_it.h"

#define BT_IRQHandler	USART3_IRQHandler

typedef struct{
	USART_TypeDef* USARTx;
	u32 		   RCC_USART;
	u32 		   RCC_GPIO;
	GPIO_TypeDef*  GPIOx;
	u16 		   TX_Pin;
	u16 		   RX_Pin;
	IRQn_Type 	   IRQn;
}BT_Config;

extern BT_Config bt;

extern char  Serial_RxPacket[];
extern u8 Serial_RxFlag;

//extern volatile u8 rxFlag;
//extern volatile u8 rxData;

void BT_Init(u32 baudrate);
void Serial_SendByte(u8 Byte);
void Serial_SendArray(u8 *Array, u16 Length);
void Serial_SendString(char *String);
void Serial_SendNumber(u32 Number, u8 Length);
void Serial_Printf(char *format, ...);

#endif
