#include "ds18b20.h"
#include "SysTick.h"

//0���ɹ���1��ʧ��

GPIO_Paramer ds18b20_GPIO={
	.GPIOx=GPIOA,
	.GPIO_Pin=GPIO_Pin_2,
	.RCC_CLK=RCC_APB2Periph_GPIOA,
};

#define DQ_H() GPIO_SetBits(ds18b20_GPIO.GPIOx,ds18b20_GPIO.GPIO_Pin)
#define DQ_L() GPIO_ResetBits(ds18b20_GPIO.GPIOx,ds18b20_GPIO.GPIO_Pin)
#define DQ_READ() GPIO_ReadInputDataBit(ds18b20_GPIO.GPIOx,ds18b20_GPIO.GPIO_Pin)

#define CMD_SKIP_ROM 	0xCC
#define	CMD_CONVERT_T 	0x44
#define CMD_READ_SP 	0xBE

static void DQ_Output(void)
{
	GPIO_InitTypeDef g;
	g.GPIO_Pin = ds18b20_GPIO.GPIO_Pin;
	g.GPIO_Mode = GPIO_Mode_Out_OD;
	g.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(ds18b20_GPIO.GPIOx, &g);
}

static void DQ_Input(void)
{
	GPIO_InitTypeDef g;
	g.GPIO_Pin = ds18b20_GPIO.GPIO_Pin;
	g.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_Init(ds18b20_GPIO.GPIOx, &g);
}

static u8 DS18B20_Reset(void)
{
	u8 presence=1;
	u16 t=0;
	
	DQ_Output();
	DQ_L();
	delay_us(500);
	DQ_H();
	DQ_Input();
	delay_us(70);
	
	if(DQ_READ()==0){
		presence=0;
		while(DQ_READ()==0 && t<300){
			delay_us(1);
			t++;
		}
	}
	delay_us(400);
	return presence;
}

static void DS18B20_WriteByte(u8 dat)
{
	u8 i;
	DQ_Output();
	for(i=0; i<8; i++){
		DQ_L();
		if(dat & 0x01){
			delay_us(3);
			DQ_H();
			delay_us(60);
		}else{
			delay_us(60);
			DQ_H();
			delay_us(3);
		}
		dat>>=1;
	}
	DQ_H();
}

static u8 DS18B20_ReadByte(void)
{
	u8 i, dat=0;
	for(i=0; i<8; i++){
		dat>>=1;
		DQ_Output();
		DQ_L();
		delay_us(2);
		DQ_H();
		DQ_Input();
		delay_us(10);
		if(DQ_READ()) dat |= 0x80;
		delay_us(50);
	}
	return dat;
}

void DS18B20_Init(void)
{
	GPIO_InitTypeDef g;
	RCC_APB2PeriphClockCmd(ds18b20_GPIO.RCC_CLK, ENABLE);
	
	g.GPIO_Pin = ds18b20_GPIO.GPIO_Pin;
	g.GPIO_Mode = GPIO_Mode_Out_OD;
	g.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(ds18b20_GPIO.GPIOx, &g);
	DQ_H();
	DS18B20_Reset();
}

u8 DS18B20_Start(void)
{
	if(DS18B20_Reset()) return 1;
	DS18B20_WriteByte(CMD_SKIP_ROM);
	DS18B20_WriteByte(CMD_CONVERT_T);
	return 0;
}

// ��ȡ�¶ȣ�*temp��λ0.1�棨��255��ʾ25.5�棩
u8 DS18B20_ReadTemp(int16_t *temp)
{
	u8 lsb, msb;
	int16_t raw;
	
	if(DS18B20_Reset()) return 1;
	DS18B20_WriteByte(CMD_SKIP_ROM);
	DS18B20_WriteByte(CMD_READ_SP);
	lsb = DS18B20_ReadByte();		// �ֽ�0
	msb = DS18B20_ReadByte();		// �ֽ�1
	DS18B20_Reset();				// ��ǰ������ȡ
	
	raw=(int16_t)((msb<<8)|lsb);	// 12λ���룬�ֱ���0.0625��
	*temp=(int16_t)(raw*10/16);		// ת��0.1�浥λ��25.5���255��
	return 0;
}
