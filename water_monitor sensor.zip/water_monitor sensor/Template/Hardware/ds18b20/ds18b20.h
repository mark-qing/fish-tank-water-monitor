#ifndef __DS18B20_H
#define __DS18B20_H

#include "stm32f10x.h"

typedef struct{
	GPIO_TypeDef* GPIOx;
	u32 GPIO_Pin;
	u32 RCC_CLK;
}GPIO_Paramer;

extern GPIO_Paramer ds18b20_GPIO;

void DS18B20_Init(void);
u8 DS18B20_Start(void);
u8 DS18B20_ReadTemp(int16_t *temp);

#endif
